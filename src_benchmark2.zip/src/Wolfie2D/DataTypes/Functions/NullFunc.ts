// @ignorePage

/**
 * A placeholder function for No Operation. Does nothing
 */
const NullFunc = () => {};

export default NullFunc;